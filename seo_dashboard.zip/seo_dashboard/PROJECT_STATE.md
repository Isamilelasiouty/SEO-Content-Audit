# PROJECT_STATE.md
_Last updated: Internal Linking Dashboard complete_

---

## Project Overview
AI-powered SEO Intelligence Dashboard  
**Deployment:** Streamlit Cloud + GitHub  
**Team:** Internal SEO team (small)

---

## Completed Modules

### ✅ Internal Linking Opportunity Detection Engine
**Status:** Complete — 55/55 tests passing

**Files:**
| File | Description |
|---|---|
| `seo_engine/internal_links.py` | Core engine: `InternalLinkEngine`, `PageNode`, `LinkOpportunity`, graph construction, PageRank, TF-IDF keyword vectors, opportunity scoring, JSON serialisation |
| `utils/link_utils.py` | Keyword extraction, cosine similarity, Jaccard overlap, anchor text suggestion, URL normalisation |
| `tests/test_internal_links.py` | 55 pytest tests across 11 test classes |

**Key decisions:**
- No heavy ML/NLP deps — pure Python + NetworkX only
- TF-IDF-like vectors computed once at engine init
- Relevance formula: `(cosine_sim × 0.55) + (keyword_overlap × 0.35) + (pagerank_bonus × 0.10)`
- Duplicate detection via `is_duplicate` flag
- Anchor text: shared n-gram → top target keyword → cleaned target title

---

### ✅ Internal Linking Dashboard (Streamlit UI)
**Status:** Complete — smoke tested, all components verified

**Files:**
| File | Description |
|---|---|
| `streamlit_app/pages/internal_links_dashboard.py` | Full Streamlit page: upload, engine run, 5 tabs, filters, export |
| `components/charts.py` | 5 Plotly charts: relevance histogram, PageRank bar, opportunity scatter, opps-per-page bar, graph health donut |
| `components/tables.py` | CSS injection, KPI cards, DataFrame builders, column configs, CSV export, section headers |

**Features delivered:**
- ✅ CSV upload (flexible column mapping: url/address/page, title, body_text, outlinks as pipe-separated)
- ✅ Sitemap XML upload (standard `<loc>` extraction with/without namespace)
- ✅ Paste raw URLs (newline-separated)
- ✅ Built-in 10-page demo dataset (no upload required)
- ✅ Engine settings in sidebar: min relevance slider, max suggestions slider
- ✅ 5 interactive Plotly charts (dark theme, no heavy rendering)
- ✅ Opportunity table with search + relevance filter + type filter
- ✅ Link column configs (clickable URLs)
- ✅ Progress column for Relevance and Overlap scores
- ✅ Orphan pages tab with search + CSV export
- ✅ Sink pages list
- ✅ PageRank tab: table + bar chart + graph metrics KPIs
- ✅ Raw data tab with export
- ✅ All CSVs downloadable: opportunities, orphans, raw crawl data
- ✅ `@st.cache_data` on engine run (JSON-serialisable hash key)
- ✅ Dark futuristic CSS (DM Mono + Syne fonts, CSS variables, no generic Streamlit look)
- ✅ KPI cards with accent colour strips

**Streamlit Cloud optimisations:**
- Engine result cached with `@st.cache_data` — re-renders don't re-run analysis
- No server-side state beyond `st.session_state`-free design (cache handles it)
- Charts use `config={"displayModeBar": False}` to reduce JS overhead
- DataFrame heights capped at 600px to avoid layout thrash
- CSS-only styling (no custom JS components)
- All heavy work in the engine layer, not the UI layer

**Run locally:**
```bash
pip install streamlit plotly networkx pandas
streamlit run streamlit_app/pages/internal_links_dashboard.py
```

---

## Pending Modules

| Module | Status | Files |
|---|---|---|
| Sitemap / deep crawler | ⬜ Not started | `seo_engine/crawler.py` |
| Content analyser | ⬜ Not started | `seo_engine/content_analysis.py` |
| Semantic SEO analysis | ⬜ Not started | `seo_engine/semantic_seo.py` |
| Search intent classifier | ⬜ Not started | `seo_engine/search_intent.py` |
| AI recommendations (Anthropic) | ⬜ Not started | `seo_engine/ai_recommendations.py` |
| Main app shell | ⬜ Not started | `app.py` |
| PDF export | ⬜ Not started | `utils/export.py` |
| Progress tracking during crawl | ⬜ Not started | integrated in crawler + UI |

---

## Repository Structure (current)

```
/
├── PROJECT_STATE.md
├── requirements.txt               (pending)
├── .env.example                   (pending)
├── README.md                      (pending)
├── app.py                         (pending — multi-page shell)
├── seo_engine/
│   ├── __init__.py
│   ├── internal_links.py          ✅
│   ├── crawler.py                 ⬜
│   ├── content_analysis.py        ⬜
│   ├── semantic_seo.py            ⬜
│   ├── search_intent.py           ⬜
│   └── ai_recommendations.py      ⬜
├── utils/
│   ├── __init__.py
│   ├── link_utils.py              ✅
│   └── export.py                  ⬜
├── components/
│   ├── __init__.py
│   ├── charts.py                  ✅
│   └── tables.py                  ✅
├── streamlit_app/
│   ├── __init__.py
│   └── pages/
│       └── internal_links_dashboard.py  ✅
└── tests/
    ├── __init__.py
    └── test_internal_links.py     ✅
```

---

## Dependencies (current)

```
networkx>=3.0
plotly>=5.0
streamlit>=1.32.0
pandas>=2.0
pytest>=7.0
```
